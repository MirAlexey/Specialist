#include "meteo.h"



struct meteo_item **AllDev   = 0;
size_t              AllCount = 0;
